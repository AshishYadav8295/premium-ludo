"use strict";

import {
  auth,
  onAuthStateChanged
} from "./firebase.js";

document.addEventListener("DOMContentLoaded", () => {
  const walletBalanceElement =
    document.getElementById("walletBalance");

  const gamesPlayedElement =
    document.getElementById("gamesPlayed");

  const gamesWonElement =
    document.getElementById("gamesWon");

  const winRateElement =
    document.getElementById("winRate");

  const transactionList =
    document.getElementById("transactionList");

  const toast =
    document.getElementById("toast");

  const toastMessage =
    document.getElementById("toastMessage");

  const API_BASE =
    window.LUDOVERSE_API_BASE ||
    (
      location.hostname === "localhost" ||
      location.hostname === "127.0.0.1"
        ? "http://127.0.0.1:3000"
        : ""
    );

  function showToast(message) {
    if (!toast || !toastMessage) {
      alert(message);
      return;
    }

    toastMessage.textContent = message;
    toast.classList.add("show");

    clearTimeout(showToast.timer);

    showToast.timer =
      setTimeout(
        () => toast.classList.remove("show"),
        3200
      );
  }

  async function apiRequest(path) {
    if (!API_BASE) {
      throw new Error(
        "LUDOVERSE backend is not configured for this deployment."
      );
    }

    const user = auth.currentUser;

    if (!user) {
      throw new Error("Authentication required.");
    }

    const token =
      await user.getIdToken();

    const response =
      await fetch(
        `${API_BASE}${path}`,
        {
          headers: {
            Authorization:
              `Bearer ${token}`
          }
        }
      );

    const payload =
      await response.json().catch(
        () => ({})
      );

    if (
      !response.ok ||
      payload.ok === false
    ) {
      throw new Error(
        payload.error ||
        `Request failed (${response.status}).`
      );
    }

    return payload;
  }

  function formatCoins(value) {
    return Math.max(
      0,
      Number(value) || 0
    ).toLocaleString("en-IN");
  }

  function escapeHTML(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function renderTransactions(
    transactions
  ) {
    if (!transactionList) {
      return;
    }

    transactionList.innerHTML = "";

    if (
      !Array.isArray(transactions) ||
      transactions.length === 0
    ) {
      transactionList.innerHTML = `
        <div class="empty-history">
          <div class="empty-icon">🪙</div>
          <h3>No activity yet</h3>
          <p>Your virtual LudoCoin activity will appear here.</p>
        </div>
      `;
      return;
    }

    transactions.forEach(
      transaction => {
        const item =
          document.createElement(
            "div"
          );

        item.className =
          "transaction-item";

        const timestamp =
          Number(transaction.createdAt);

        const date =
          new Date(timestamp);

        const formattedDate =
          Number.isFinite(timestamp) &&
          !Number.isNaN(date.getTime())
            ? date.toLocaleString()
            : "";

        const coins =
          Number(transaction.coins) || 0;

        const positive =
          coins > 0;

        item.innerHTML = `
          <div class="transaction-left">
            <div class="transaction-icon ${
              positive
                ? "credit"
                : "debit"
            }">
              ${positive ? "🪙" : "🎮"}
            </div>
            <div>
              <h4>
                ${escapeHTML(
                  transaction.description ||
                  "LUDOVERSE Match Activity"
                )}
              </h4>
              <p>${escapeHTML(formattedDate)}</p>
            </div>
          </div>

          <div class="transaction-amount ${
            positive
              ? "positive"
              : "negative"
          }">
            ${
              positive
                ? "+"
                : ""
            }${formatCoins(coins)}
          </div>
        `;

        transactionList.appendChild(item);
      }
    );
  }

  async function loadEconomy() {
    const payload =
      await apiRequest(
        "/api/economy"
      );

    const economy =
      payload.economy || {};

    if (walletBalanceElement) {
      walletBalanceElement.textContent =
        formatCoins(
          economy.ludoCoins
        );
    }

    if (gamesPlayedElement) {
      gamesPlayedElement.textContent =
        formatCoins(
          economy.gamesPlayed
        );
    }

    if (gamesWonElement) {
      gamesWonElement.textContent =
        formatCoins(
          economy.gamesWon
        );
    }

    if (winRateElement) {
      const played =
        Number(
          economy.gamesPlayed
        ) || 0;

      const won =
        Number(
          economy.gamesWon
        ) || 0;

      winRateElement.textContent =
        played > 0
          ? `${Math.round(
              (won / played) * 100
            )}%`
          : "0%";
    }

    renderTransactions(
      payload.transactions || []
    );
  }

  onAuthStateChanged(
    auth,
    async user => {
      if (!user) {
        window.location.href =
          "login.html";
        return;
      }

      try {
        await loadEconomy();
      } catch (error) {
        console.error(
          "Wallet economy load failed:",
          error
        );

        showToast(
          error?.message ||
          "Could not load your LudoCoin wallet."
        );
      }
    }
  );
});
