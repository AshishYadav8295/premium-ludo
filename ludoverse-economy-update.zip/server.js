import "dotenv/config";
import express from "express";
import cors from "cors";
import fs from "node:fs";
import crypto from "node:crypto";

import {
  cert,
  getApps,
  initializeApp
} from "firebase-admin/app";

import {
  getAuth
} from "firebase-admin/auth";

import {
  getDatabase
} from "firebase-admin/database";


/* =========================================================
   CONFIG
========================================================= */

const PORT = Number(process.env.PORT || 3000);

const serviceAccountPath =
  process.env.FIREBASE_SERVICE_ACCOUNT_PATH;

if (!serviceAccountPath) {
  throw new Error(
    "FIREBASE_SERVICE_ACCOUNT_PATH is not configured."
  );
}

if (!fs.existsSync(serviceAccountPath)) {
  throw new Error(
    `Firebase service account file not found: ${serviceAccountPath}`
  );
}

const serviceAccount =
  JSON.parse(
    fs.readFileSync(
      serviceAccountPath,
      "utf8"
    )
  );


/* =========================================================
   FIREBASE ADMIN
========================================================= */

const firebaseApp =
  getApps().length > 0
    ? getApps()[0]
    : initializeApp({
        credential:
          cert(serviceAccount),

        databaseURL:
          "https://ludoverse-d4338-default-rtdb.firebaseio.com"
      });

const database =
  getDatabase(firebaseApp);

const firebaseAuth =
  getAuth(firebaseApp);


/* =========================================================
   EXPRESS
========================================================= */

const app =
  express();

app.disable("x-powered-by");

app.use(
  cors()
);

app.use(
  express.json({
    limit: "100kb"
  })
);


/* =========================================================
   CONSTANTS
========================================================= */

const HOME_POSITION =
  -1;

const FINISHED_POSITION =
  56;

const TRACK = [
  [6,1],
  [6,2],
  [6,3],
  [6,4],
  [6,5],

  [5,6],
  [4,6],
  [3,6],
  [2,6],
  [1,6],
  [0,6],

  [0,7],

  [0,8],
  [1,8],
  [2,8],
  [3,8],
  [4,8],
  [5,8],

  [6,9],
  [6,10],
  [6,11],
  [6,12],
  [6,13],
  [6,14],

  [7,14],

  [8,14],
  [8,13],
  [8,12],
  [8,11],
  [8,10],
  [8,9],

  [9,8],
  [10,8],
  [11,8],
  [12,8],
  [13,8],
  [14,8],

  [14,7],

  [14,6],
  [13,6],
  [12,6],
  [11,6],
  [10,6],
  [9,6],

  [8,5],
  [8,4],
  [8,3],
  [8,2],
  [8,1],
  [8,0],

  [7,0],

  [6,0]
];

const START = {
  red: 0,
  yellow: 26
};

const HOME = {
  red: [
    [7,1],
    [7,2],
    [7,3],
    [7,4],
    [7,5],
    [7,6]
  ],

  yellow: [
    [7,13],
    [7,12],
    [7,11],
    [7,10],
    [7,9],
    [7,8]
  ]
};

const SAFE = new Set([
  "2:6",
  "6:12",
  "8:2",
  "12:8",
  "6:1",
  "8:13"
]);


/* =========================================================
   HELPERS
========================================================= */

function cellKey(
  coordinate
) {
  return `${coordinate[0]}:${coordinate[1]}`;
}


function coordinateFor(
  color,
  position
) {
  position =
    Number(position);

  if (
    position < 0 ||
    position > FINISHED_POSITION
  ) {
    return null;
  }

  if (position <= 50) {
    return TRACK[
      (
        START[color] +
        position
      ) % 52
    ];
  }

  return (
    HOME[color][
      position - 51
    ] || null
  );
}


function createInitialTokens() {
  return {
    red: [
      {
        id: 0,
        position: HOME_POSITION,
        finished: false
      },
      {
        id: 1,
        position: HOME_POSITION,
        finished: false
      },
      {
        id: 2,
        position: HOME_POSITION,
        finished: false
      },
      {
        id: 3,
        position: HOME_POSITION,
        finished: false
      }
    ],

    yellow: [
      {
        id: 0,
        position: HOME_POSITION,
        finished: false
      },
      {
        id: 1,
        position: HOME_POSITION,
        finished: false
      },
      {
        id: 2,
        position: HOME_POSITION,
        finished: false
      },
      {
        id: 3,
        position: HOME_POSITION,
        finished: false
      }
    ]
  };
}


function isValidToken(
  token,
  number
) {
  if (!token) {
    return false;
  }

  if (
    Number(token.position) ===
    FINISHED_POSITION
  ) {
    return false;
  }

  if (
    Number(token.position) ===
    HOME_POSITION
  ) {
    return number === 6;
  }

  return (
    Number(token.position) +
      number <=
    FINISHED_POSITION
  );
}


function finishedCount(
  tokens,
  color
) {
  return tokens[color]
    .filter(
      token =>
        Number(token.position) ===
        FINISHED_POSITION
    )
    .length;
}


function getWinner(
  tokens
) {
  if (
    finishedCount(tokens, "red") ===
    4
  ) {
    return "red";
  }

  if (
    finishedCount(tokens, "yellow") ===
    4
  ) {
    return "yellow";
  }

  return null;
}


function otherColor(
  color
) {
  return color === "red"
    ? "yellow"
    : "red";
}


function validColor(
  color
) {
  return (
    color === "red" ||
    color === "yellow"
  );
}


/* =========================================================
   AUTH MIDDLEWARE
========================================================= */

async function requireAuth(
  req,
  res,
  next
) {
  try {
    const header =
      req.headers.authorization || "";

    if (
      !header.startsWith(
        "Bearer "
      )
    ) {
      return res.status(401).json({
        ok: false,
        error: "Authentication required."
      });
    }

    const idToken =
      header.slice(7).trim();

    if (!idToken) {
      return res.status(401).json({
        ok: false,
        error: "Authentication token missing."
      });
    }

    req.user =
      await firebaseAuth.verifyIdToken(
        idToken
      );

    next();

  } catch (error) {
    console.error(
      "Authentication failed:",
      error.message
    );

    return res.status(401).json({
      ok: false,
      error: "Invalid or expired authentication token."
    });
  }
}


/* =========================================================
   ROOM ACCESS
========================================================= */

async function getRoomForUser(
  roomCode,
  uid
) {
  const snapshot =
    await database
      .ref(`battles/${roomCode}`)
      .once("value");

  const battle =
    snapshot.val();

  if (!battle) {
    throw new Error(
      "Room not found."
    );
  }

  const players =
    battle.players || {};

  const player =
    players[uid];

  if (!player) {
    throw new Error(
      "You are not a player in this room."
    );
  }

  return {
    battle,
    player
  };
}


/* =========================================================
   HEALTH
========================================================= */

app.get(
  "/health",
  (_req, res) => {
    res.json({
      ok: true,
      service:
        "LUDOVERSE backend"
    });
  }
);


/* =========================================================
   AUTHENTICATED FIREBASE TEST
========================================================= */

app.get(
  "/api/auth-check",
  requireAuth,
  async (req, res) => {
    res.json({
      ok: true,
      uid: req.user.uid
    });
  }
);



/* =========================================================
   GAME PLAYER / STATE HELPERS
   ========================================================= */

function getPlayerColorFromGame(current, uid){

  const players =
    current?.players || {};

  if(
    String(players.red || "") ===
    String(uid)
  ){
    return "red";
  }

  if(
    String(players.yellow || "") ===
    String(uid)
  ){
    return "yellow";
  }

  return null;
}


function buildInitialGame(
  roomCode,
  redUid,
  yellowUid
){

  return {
    roomCode,

    players:{
      red:redUid || null,
      yellow:yellowUid || null
    },

    tokens:
      createInitialTokens(),

    finished:{
      red:0,
      yellow:0
    },

    turn:"red",

    dice:0,

    diceRoll:null,

    phase:"roll",

    winner:null,

    sixCount:{
      red:0,
      yellow:0
    },

    moveAnimation:null,

    version:1,

    updatedAt:
      Date.now()
  };
}


/* =========================================================
   INITIALIZE GAME
   ========================================================= */

app.post(
  "/api/game/initialize",
  requireAuth,
  async (req,res) => {

    const roomCode =
      String(
        req.body?.roomCode || ""
      ).trim();

    if(!roomCode){
      return res.status(400).json({
        ok:false,
        error:"Room code is required."
      });
    }

    try{

      const {battle} =
        await getRoomForUser(
          roomCode,
          req.user.uid
        );

      const gameRef =
        database.ref(
          `games/${roomCode}`
        );

      const creatorUid =
        battle.creatorUid || null;

      const players =
        battle.players || {};

      let yellowUid = null;

      Object.keys(players).forEach(uid => {

        if(
          String(uid) !==
          String(creatorUid)
        ){
          yellowUid = uid;
        }

      });

      const result =
        await gameRef.transaction(
          current => {

            if(current){
              return current;
            }

            /*
              Only Player 1 / room creator creates
              the first game snapshot.
            */
            if(
              String(creatorUid || "") !==
              String(req.user.uid)
            ){
              return;
            }

            return buildInitialGame(
              roomCode,
              creatorUid,
              yellowUid
            );
          }
        );

      if(
        !result.committed &&
        !result.snapshot.exists()
      ){
        return res.status(409).json({
          ok:false,
          error:
            "Game could not be initialized."
        });
      }

      return res.json({
        ok:true,
        game:
          result.snapshot.val()
      });

    }catch(error){

      console.error(
        "Game initialization failed:",
        error
      );

      return res.status(400).json({
        ok:false,
        error:
          error.message ||
          "Could not initialize game."
      });
    }
  }
);


/* =========================================================
   SERVER AUTHORITATIVE DICE ROLL
   ========================================================= */

app.post(
  "/api/game/roll",
  requireAuth,
  async (req,res) => {

    const roomCode =
      String(
        req.body?.roomCode || ""
      ).trim();

    if(!roomCode){
      return res.status(400).json({
        ok:false,
        error:"Room code is required."
      });
    }

    try{

      await getRoomForUser(
        roomCode,
        req.user.uid
      );

      const gameRef =
        database.ref(
          `games/${roomCode}`
        );

      /*
        Firebase transactions can invoke the callback with null
        before the remote value has been loaded into the local
        transaction cache. Read the authoritative snapshot first
        and use it only as the null fallback. If another write
        happens, Firebase will retry the transaction with the
        newer current value.
      */
      const initialSnapshot =
        await gameRef.once("value");

      const initialGame =
        initialSnapshot.val();

      if(!initialGame){
        return res.status(409).json({
          ok:false,
          error:"Game state does not exist yet."
        });
      }

      const result =
        await gameRef.transaction(
          current => {

            const game =
              current || initialGame;

            if(!game){
              return;
            }

            const color =
              getPlayerColorFromGame(
                game,
                req.user.uid
              );

            if(!validColor(color)){
              console.error(
                "ROLL REJECTED: user is not mapped to a game color.",
                {
                  uid:req.user.uid,
                  red:game.players?.red,
                  yellow:game.players?.yellow
                }
              );
              return;
            }

            if(
              game.winner ||
              game.phase !== "roll" ||
              game.turn !== color
            ){
              console.error(
                "ROLL REJECTED: game state condition failed.",
                {
                  uid:req.user.uid,
                  color,
                  winner:game.winner,
                  phase:game.phase,
                  turn:game.turn,
                  red:game.players?.red,
                  yellow:game.players?.yellow
                }
              );
              return;
            }

            const number =
              crypto.randomInt(1,7);

            const now =
              Date.now();

            /*
              The backend publishes the rolling event.
              The result is NOT resolved here, so both
              clients can display the same dice animation.
            */
            return {
              ...game,

              dice:0,

              diceRoll:{
                id:
                  crypto.randomUUID(),

                ownerUid:
                  req.user.uid,

                color,

                number,

                startedAt:now,

                resolveAfter:
                  now + 900
              },

              phase:"rolling",

              updatedAt:now
            };
          }
        );

      if(!result.committed){
        return res.status(409).json({
          ok:false,
          error:
            "Dice roll was rejected because the game state changed."
        });
      }

      return res.json({
        ok:true,
        game:
          result.snapshot.val()
      });

    }catch(error){

      console.error(
        "Roll failed:",
        error
      );

      return res.status(400).json({
        ok:false,
        error:
          error.message ||
          "Could not roll dice."
      });
    }
  }
);


/* =========================================================
   RESOLVE DICE
   ========================================================= */

app.post(
  "/api/game/roll/resolve",
  requireAuth,
  async (req,res) => {

    const roomCode =
      String(
        req.body?.roomCode || ""
      ).trim();

    const rollId =
      String(
        req.body?.rollId || ""
      ).trim();

    if(
      !roomCode ||
      !rollId
    ){
      return res.status(400).json({
        ok:false,
        error:
          "Room code and rollId are required."
      });
    }

    try{

      await getRoomForUser(
        roomCode,
        req.user.uid
      );

      const gameRef =
        database.ref(
          `games/${roomCode}`
        );

      /*
        Firebase transactions can initially invoke the callback
        with null before the remote value is available locally.
        Load the authoritative state first and use it as the
        null fallback. Concurrent changes are still handled by
        Firebase transaction retries.
      */
      const initialSnapshot =
        await gameRef.once("value");

      const initialGame =
        initialSnapshot.val();

      if(!initialGame){
        return res.status(409).json({
          ok:false,
          error:
            "Game state does not exist yet."
        });
      }

      const result =
        await gameRef.transaction(
          current => {

            const game =
              current || initialGame;

            if(!game){
              return;
            }

            const roll =
              game.diceRoll;

            /*
              Idempotent behaviour:
              if this roll has already been resolved,
              simply keep the current authoritative state.
            */
            if(
              !roll ||
              roll.id !== rollId ||
              game.phase !== "rolling"
            ){
              return game;
            }

            if(
              String(roll.ownerUid) !==
              String(req.user.uid)
            ){
              return;
            }

            const color =
              getPlayerColorFromGame(
                game,
                req.user.uid
              );

            if(!validColor(color)){
              return;
            }

            const number =
              Number(roll.number);

            if(
              !Number.isInteger(number) ||
              number < 1 ||
              number > 6
            ){
              return;
            }

            const sixCount =
              game.sixCount || {
                red:0,
                yellow:0
              };

            const currentSixes =
              Number(
                sixCount[color] || 0
              );

            const newSixes =
              number === 6
                ? currentSixes + 1
                : 0;

            const next =
              otherColor(color);

            /*
              Three consecutive sixes:
              lose the turn.
            */
            if(newSixes >= 3){

              return {
                ...game,

                dice:number,

                diceRoll:null,

                phase:"roll",

                turn:next,

                sixCount:{
                  ...sixCount,
                  [color]:0,
                  [next]:0
                },

                updatedAt:
                  Math.max(
                    Date.now(),
                    Number(
                      game.updatedAt || 0
                    ) + 1
                  )
              };
            }

            const tokens =
              game.tokens || {
                red:[],
                yellow:[]
              };

            const hasValidMove =
              (tokens[color] || [])
                .some(token =>
                  isValidToken(
                    token,
                    number
                  )
                );

            /*
              No legal token:
              6 => same player rolls again
              otherwise => opponent turn
            */
            if(!hasValidMove){

              return {
                ...game,

                dice:number,

                diceRoll:null,

                phase:"roll",

                turn:
                  number === 6
                    ? color
                    : next,

                sixCount:{
                  ...sixCount,

                  [color]:
                    number === 6
                      ? newSixes
                      : 0,

                  [next]:
                    number === 6
                      ? newSixes
                      : 0
                },

                updatedAt:
                  Math.max(
                    Date.now(),
                    Number(
                      game.updatedAt || 0
                    ) + 1
                  )
              };
            }

            return {
              ...game,

              dice:number,

              diceRoll:null,

              phase:"move",

              turn:color,

              sixCount:{
                ...sixCount,
                [color]:newSixes
              },

              updatedAt:
                Math.max(
                  Date.now(),
                  Number(
                    game.updatedAt || 0
                  ) + 1
                )
            };
          }
        );

      if(!result.committed){
        return res.status(409).json({
          ok:false,
          error:
            "Dice result could not be resolved."
        });
      }

      return res.json({
        ok:true,
        game:
          result.snapshot.val()
      });

    }catch(error){

      console.error(
        "Dice resolution failed:",
        error
      );

      return res.status(400).json({
        ok:false,
        error:
          error.message ||
          "Could not resolve dice."
      });
    }
  }
);


/* =========================================================
   AUTHORITATIVE TOKEN MOVE
   ========================================================= */

app.post(
  "/api/game/move",
  requireAuth,
  async (req,res) => {

    const roomCode =
      String(
        req.body?.roomCode || ""
      ).trim();

    const tokenId =
      Number(
        req.body?.tokenId
      );

    if(
      !roomCode ||
      !Number.isInteger(tokenId) ||
      tokenId < 0 ||
      tokenId > 3
    ){
      return res.status(400).json({
        ok:false,
        error:
          "Valid roomCode and tokenId are required."
      });
    }

    try{

      await getRoomForUser(
        roomCode,
        req.user.uid
      );

      const gameRef =
        database.ref(
          `games/${roomCode}`
        );

      /*
        Firebase Admin transactions can initially invoke the
        callback with null before the remote value has been
        loaded into the transaction cache.

        Load the authoritative game snapshot first and use it
        only as the null fallback. If another client changes
        the game, Firebase will retry the transaction against
        the newer authoritative value.
      */
      const initialSnapshot =
        await gameRef.once("value");

      const initialGame =
        initialSnapshot.val();

      if(!initialGame){
        return res.status(409).json({
          ok:false,
          error:
            "Game state does not exist yet."
        });
      }

      const result =
        await gameRef.transaction(
          current => {

            const game =
              current || initialGame;

            if(!game){
              return;
            }

            const color =
              getPlayerColorFromGame(
                game,
                req.user.uid
              );

            if(!validColor(color)){
              return;
            }

            if(
              game.winner ||
              game.phase !== "move" ||
              game.turn !== color
            ){
              return;
            }

            const number =
              Number(game.dice);

            if(
              !Number.isInteger(number) ||
              number < 1 ||
              number > 6
            ){
              return;
            }

            const tokens = {
              red:
                (game.tokens?.red || [])
                  .map(token => ({
                    ...token
                  })),

              yellow:
                (game.tokens?.yellow || [])
                  .map(token => ({
                    ...token
                  }))
            };

            const movingToken =
              tokens[color][tokenId];

            if(
              !isValidToken(
                movingToken,
                number
              )
            ){
              return;
            }

            const fromPosition =
              Number(
                movingToken.position
              );

            /*
              Preserve the existing HOME-token
              visual ordering behaviour.
            */
            const homeTokensBeforeMove =
              tokens[color]
                .filter(token =>
                  Number(token.position) ===
                  HOME_POSITION
                )
                .sort(
                  (a,b) =>
                    Number(a.id) -
                    Number(b.id)
                );

            const fromHomeIndex =
              fromPosition === HOME_POSITION
                ? Math.max(
                    0,
                    homeTokensBeforeMove.findIndex(
                      token =>
                        Number(token.id) ===
                        tokenId
                    )
                  )
                : null;

            const toPosition =
              fromPosition === HOME_POSITION
                ? 0
                : fromPosition + number;

            if(
              toPosition >
              FINISHED_POSITION
            ){
              return;
            }

            movingToken.position =
              toPosition;

            movingToken.finished =
              toPosition ===
              FINISHED_POSITION;

            let captured = false;

            const coordinate =
              coordinateFor(
                color,
                toPosition
              );

            /*
              Capture only happens on an unsafe
              outer-track cell.
            */
            if(
              coordinate &&
              toPosition <= 50 &&
              !SAFE.has(
                cellKey(coordinate)
              )
            ){

              const opponent =
                otherColor(color);

              const targetKey =
                cellKey(coordinate);

              tokens[opponent]
                .forEach(
                  opponentToken => {

                    const opponentPosition =
                      Number(
                        opponentToken.position
                      );

                    if(
                      opponentPosition >= 0 &&
                      opponentPosition <= 50
                    ){

                      const opponentCoordinate =
                        coordinateFor(
                          opponent,
                          opponentPosition
                        );

                      if(
                        opponentCoordinate &&
                        cellKey(
                          opponentCoordinate
                        ) === targetKey
                      ){

                        opponentToken.position =
                          HOME_POSITION;

                        opponentToken.finished =
                          false;

                        captured = true;
                      }
                    }
                  }
                );
            }

            const winner =
              getWinner(tokens);

            const finishedToken =
              toPosition ===
              FINISHED_POSITION;

            const extraTurn =
              number === 6 ||
              captured ||
              finishedToken;

            const nextTurn =
              winner
                ? color
                : extraTurn
                  ? color
                  : otherColor(color);

            const oldSixCount =
              game.sixCount || {
                red:0,
                yellow:0
              };

            const nextSixCount =
              number === 6
                ? (
                    captured
                      ? 0
                      : Number(
                          oldSixCount[color] || 0
                        )
                  )
                : 0;

            const finished = {
              red:
                finishedCount(
                  tokens,
                  "red"
                ),

              yellow:
                finishedCount(
                  tokens,
                  "yellow"
                )
            };

            const steps =
              fromPosition === HOME_POSITION
                ? 1
                : number;

            const stepDuration =
              fromPosition === HOME_POSITION
                ? 420
                : 120;

            const duration =
              stepDuration * steps;

            const now =
              Date.now();

            const moveId =
              `${color}-${tokenId}-${now}-${crypto.randomUUID().slice(0,8)}`;

            const finalUpdatedAt =
              now +
              120 +
              duration +
              1;

            const resultState = {
              tokens,

              finished,

              dice:0,

              phase:
                winner
                  ? "finished"
                  : "roll",

              turn:nextTurn,

              winner,

              sixCount:{
                ...oldSixCount,
                [color]:
                  nextSixCount
              }
            };

            return {
              ...game,

              /*
                Destination state is stored immediately,
                but UI animation still shows the movement proxy.
              */
              tokens,

              finished,

              phase:"animating",

              dice:number,

              moveAnimation:{
                id:moveId,

                ownerUid:
                  req.user.uid,

                color,

                tokenId,

                fromPosition,

                fromHomeIndex,

                toPosition,

                steps,

                duration,

                startedAt:
                  now + 120,

                finalUpdatedAt,

                result:resultState
              },

              updatedAt:now
            };
          }
        );

      if(!result.committed){
        return res.status(409).json({
          ok:false,
          error:
            "Move was rejected because the game state changed or the move is invalid."
        });
      }

      return res.json({
        ok:true,
        game:
          result.snapshot.val()
      });

    }catch(error){

      console.error(
        "Move failed:",
        error
      );

      return res.status(400).json({
        ok:false,
        error:
          error.message ||
          "Could not move token."
      });
    }
  }
);


/* =========================================================
   COMPLETE MOVEMENT ANIMATION
   ========================================================= */

app.post(
  "/api/game/move/complete",
  requireAuth,
  async (req,res) => {

    const roomCode =
      String(
        req.body?.roomCode || ""
      ).trim();

    const moveId =
      String(
        req.body?.moveId || ""
      ).trim();

    if(
      !roomCode ||
      !moveId
    ){
      return res.status(400).json({
        ok:false,
        error:
          "Room code and moveId are required."
      });
    }

    try{

      await getRoomForUser(
        roomCode,
        req.user.uid
      );

      const gameRef =
        database.ref(
          `games/${roomCode}`
        );

      /*
        Use a fresh authoritative snapshot as the null fallback
        for Firebase transaction initialization.
      */
      const initialSnapshot =
        await gameRef.once("value");

      const initialGame =
        initialSnapshot.val();

      if(!initialGame){
        return res.status(409).json({
          ok:false,
          error:
            "Game state does not exist yet."
        });
      }

      const result =
        await gameRef.transaction(
          current => {

            const game =
              current || initialGame;

            if(!game){
              return;
            }

            const move =
              game.moveAnimation;

            /*
              Idempotent:
              if another client already completed
              this move, return current state.
            */
            if(
              !move ||
              move.id !== moveId
            ){
              return game;
            }

            const isOwner =
              String(move.ownerUid) ===
              String(req.user.uid);

            const elapsed =
              Date.now() -
              Number(
                move.startedAt || 0
              );

            /*
              Non-owner recovery is allowed only
              after the animation should have finished.
            */
            const recoveryAllowed =
              elapsed >=
              Math.max(
                0,
                Number(move.duration || 0)
              );

            if(
              !isOwner &&
              !recoveryAllowed
            ){
              return;
            }

            const resultState =
              move.result;

            if(!resultState){
              return;
            }

            return {
              ...game,

              tokens:
                resultState.tokens,

              finished:
                resultState.finished,

              dice:
                Number(
                  resultState.dice || 0
                ),

              phase:
                resultState.phase,

              turn:
                resultState.turn,

              winner:
                resultState.winner,

              sixCount:
                resultState.sixCount,

              moveAnimation:null,

              updatedAt:
                Math.max(
                  Date.now(),
                  Number(
                    move.finalUpdatedAt || 0
                  ),
                  Number(
                    game.updatedAt || 0
                  ) + 1
                )
            };
          }
        );

      if(!result.committed){

        const snapshot =
          result.snapshot.val();

        if(
          snapshot &&
          !snapshot.moveAnimation
        ){
          return res.json({
            ok:true,
            game:snapshot
          });
        }

        return res.status(409).json({
          ok:false,
          error:
            "Move completion was rejected."
        });
      }

      return res.json({
        ok:true,
        game:
          result.snapshot.val()
      });

    }catch(error){

      console.error(
        "Move completion failed:",
        error
      );

      return res.status(400).json({
        ok:false,
        error:
          error.message ||
          "Could not complete move."
      });
    }
  }
);


/* =========================================================
   RESTART GAME
   ========================================================= */

app.post(
  "/api/game/restart",
  requireAuth,
  async (req,res) => {

    const roomCode =
      String(
        req.body?.roomCode || ""
      ).trim();

    if(!roomCode){
      return res.status(400).json({
        ok:false,
        error:
          "Room code is required."
      });
    }

    try{

      await getRoomForUser(
        roomCode,
        req.user.uid
      );

      const gameRef =
        database.ref(
          `games/${roomCode}`
        );

      const result =
        await gameRef.transaction(
          current => {

            if(!current){
              return;
            }

            const color =
              getPlayerColorFromGame(
                game,
                req.user.uid
              );

            if(!validColor(color)){
              return;
            }

            const fresh =
              buildInitialGame(
                roomCode,
                current.players?.red || null,
                current.players?.yellow || null
              );

            fresh.version =
              Number(
                current.version || 1
              ) + 1;

            return fresh;
          }
        );

      if(!result.committed){
        return res.status(409).json({
          ok:false,
          error:
            "Game restart was rejected."
        });
      }

      return res.json({
        ok:true,
        game:
          result.snapshot.val()
      });

    }catch(error){

      console.error(
        "Restart failed:",
        error
      );

      return res.status(400).json({
        ok:false,
        error:
          error.message ||
          "Could not restart game."
      });
    }
  }
);


/* =========================================================
   SERVER-AUTHORITATIVE VIRTUAL LUDOCOIN ECONOMY
   ---------------------------------------------------------
   LudoCoins are non-cash virtual game points.
   They are never an entry fee, stake, cash prize, withdrawal,
   or transfer from one player to another.
========================================================= */

const STARTER_LUDOCOINS = 1000;
const MAX_REWARD_TIER = 10000;
const MAX_SYSTEM_REWARD = 20000;

function normalizeEconomyRecord(data = {}) {
  const source =
    data && typeof data === "object"
      ? data
      : {};

  return {
    ludoCoins: Math.max(0, Number(source.ludoCoins) || 0),
    gamesPlayed: Math.max(0, Number(source.gamesPlayed) || 0),
    gamesWon: Math.max(0, Number(source.gamesWon) || 0),
    updatedAt: Number(source.updatedAt) || 0,
    settledGames:
      source.settledGames &&
      typeof source.settledGames === "object"
        ? source.settledGames
        : {}
  };
}

async function ensureEconomyForUser(uid) {
  const economyRef =
    database.ref(`users/${uid}/economy`);

  const snapshot =
    await economyRef.once("value");

  if (!snapshot.exists()) {
    const initial = {
      ludoCoins: STARTER_LUDOCOINS,
      gamesPlayed: 0,
      gamesWon: 0,
      updatedAt: Date.now(),
      settledGames: {}
    };

    await economyRef.set(initial);
    return normalizeEconomyRecord(initial);
  }

  return normalizeEconomyRecord(snapshot.val());
}

async function readCoinTransactions(uid) {
  const snapshot =
    await database
      .ref(`users/${uid}/coinTransactions`)
      .once("value");

  if (!snapshot.exists()) {
    return [];
  }

  return Object.entries(snapshot.val() || {})
    .map(([id, value]) => ({
      id,
      ...(value || {})
    }))
    .sort(
      (a, b) =>
        Number(b.createdAt || 0) -
        Number(a.createdAt || 0)
    )
    .slice(0, 100);
}

function sanitizeRewardTier(value) {
  const amount = Number(value);

  if (
    !Number.isInteger(amount) ||
    amount < 0 ||
    amount > MAX_REWARD_TIER
  ) {
    return 0;
  }

  return amount;
}

function makeSettlementKey(roomCode) {
  return String(roomCode)
    .replace(/[^a-zA-Z0-9_-]/g, "_");
}

/* ---------------------------------------------------------
   GET CURRENT ECONOMY
--------------------------------------------------------- */

app.get(
  "/api/economy",
  requireAuth,
  async (req, res) => {
    try {
      const economy =
        await ensureEconomyForUser(req.user.uid);

      const transactions =
        await readCoinTransactions(req.user.uid);

      return res.json({
        ok: true,
        economy: {
          ludoCoins: economy.ludoCoins,
          gamesPlayed: economy.gamesPlayed,
          gamesWon: economy.gamesWon,
          updatedAt: economy.updatedAt
        },
        transactions
      });
    } catch (error) {
      console.error("Economy read failed:", error);

      return res.status(500).json({
        ok: false,
        error: "Could not load LudoCoin data."
      });
    }
  }
);

/* ---------------------------------------------------------
   AUTHORITATIVE MATCH RESULT SETTLEMENT
   ---------------------------------------------------------
   A selected reward tier is a system-issued virtual reward.
   No player's balance is deducted.
--------------------------------------------------------- */

app.post(
  "/api/game/result",
  requireAuth,
  async (req, res) => {
    const roomCode =
      String(req.body?.roomCode || "").trim();

    if (!roomCode) {
      return res.status(400).json({
        ok: false,
        error: "Room code is required."
      });
    }

    try {
      const roomSnapshot =
        await database
          .ref(`battles/${roomCode}`)
          .once("value");

      if (!roomSnapshot.exists()) {
        return res.status(404).json({
          ok: false,
          error: "Battle room not found."
        });
      }

      const battle = roomSnapshot.val() || {};
      const players = battle.players || {};

      if (!players[req.user.uid]) {
        return res.status(403).json({
          ok: false,
          error: "You are not a player in this battle."
        });
      }

      const gameSnapshot =
        await database
          .ref(`games/${roomCode}`)
          .once("value");

      if (!gameSnapshot.exists()) {
        return res.status(409).json({
          ok: false,
          error: "The multiplayer game has not been initialized."
        });
      }

      const game = gameSnapshot.val() || {};
      const winnerColor =
        game.winner === "red" || game.winner === "yellow"
          ? game.winner
          : null;

      if (!winnerColor) {
        return res.status(409).json({
          ok: false,
          error: "The game does not contain a completed winner yet."
        });
      }

      const winnerUid =
        String(game.players?.[winnerColor] || "");

      const loserColor =
        winnerColor === "red" ? "yellow" : "red";

      const loserUid =
        String(game.players?.[loserColor] || "");

      if (
        !winnerUid ||
        !loserUid ||
        !players[winnerUid] ||
        !players[loserUid]
      ) {
        return res.status(409).json({
          ok: false,
          error: "The match participants could not be resolved."
        });
      }

      const tier =
        battle.entryMode === "coins"
          ? sanitizeRewardTier(battle.coinAmount)
          : 0;

      const winnerReward =
        Math.min(MAX_SYSTEM_REWARD, tier * 2);

      const settlementKey =
        makeSettlementKey(roomCode);

      const now = Date.now();

      async function settlePlayer(uid, won, reward) {
        const economyRef =
          database.ref(`users/${uid}/economy`);

        let alreadySettled = false;

        const transactionResult =
          await economyRef.transaction(current => {
            const economy =
              normalizeEconomyRecord(current || {});

            const settledGames = {
              ...economy.settledGames
            };

            if (settledGames[settlementKey]) {
              alreadySettled = true;
              return economy;
            }

            settledGames[settlementKey] = {
              roomCode,
              result: won ? "won" : "lost",
              reward: Number(reward) || 0,
              settledAt: now
            };

            return {
              ...economy,
              ludoCoins:
                economy.ludoCoins + (Number(reward) || 0),
              gamesPlayed:
                economy.gamesPlayed + 1,
              gamesWon:
                economy.gamesWon + (won ? 1 : 0),
              settledGames,
              updatedAt: now
            };
          });

        if (
          !transactionResult.committed &&
          !alreadySettled
        ) {
          throw new Error(
            "Could not settle player economy."
          );
        }

        const transactionId =
          `game_${settlementKey}_${won ? "win" : "loss"}`;

        await database
          .ref(
            `users/${uid}/coinTransactions/${transactionId}`
          )
          .set({
            type:
              won && reward > 0
                ? "game_reward"
                : "game_result",
            coins: Number(reward) || 0,
            description:
              won
                ? reward > 0
                  ? `Match won • +${Number(reward).toLocaleString("en-IN")} LudoCoins`
                  : "Match won • Free Play"
                : "Match lost • No LudoCoin deduction",
            roomCode,
            result: won ? "won" : "lost",
            createdAt: now
          });

        return {
          alreadySettled,
          reward: Number(reward) || 0
        };
      }

      const winnerSettlement =
        await settlePlayer(
          winnerUid,
          true,
          winnerReward
        );

      await settlePlayer(
        loserUid,
        false,
        0
      );

      await database
        .ref(`battles/${roomCode}`)
        .update({
          status: "completed",
          winnerUid,
          winnerName:
            String(players[winnerUid]?.name || "Winner"),
          winnerColor,
          loserUid,
          loserName:
            String(players[loserUid]?.name || "Opponent"),
          rewardTier: tier,
          winnerReward,
          settlementKey,
          settlementStatus: "completed",
          completedAt: now,
          updatedAt: now
        });

      return res.json({
        ok: true,
        alreadySettled:
          winnerSettlement.alreadySettled,
        roomCode,
        winnerUid,
        winnerColor,
        winnerReward,
        rewardTier: tier,
        settlementStatus: "completed"
      });
    } catch (error) {
      console.error(
        "Game result settlement failed:",
        error
      );

      return res.status(500).json({
        ok: false,
        error:
          error.message ||
          "Could not settle the match result."
      });
    }
  }
);

/* ---------------------------------------------------------
   ADMIN VIRTUAL COIN ADJUSTMENT
   ---------------------------------------------------------
   Configure ADMIN_UIDS in the backend environment as a
   comma-separated list of Firebase Auth UIDs.
--------------------------------------------------------- */

function isAdminUid(uid) {
  const configured =
    String(process.env.ADMIN_UIDS || "")
      .split(",")
      .map(value => value.trim())
      .filter(Boolean);

  return configured.includes(String(uid));
}

app.post(
  "/api/admin/economy/adjust",
  requireAuth,
  async (req, res) => {
    if (!isAdminUid(req.user.uid)) {
      return res.status(403).json({
        ok: false,
        error: "Admin authorization required."
      });
    }

    const targetUid =
      String(req.body?.uid || "").trim();

    const delta =
      Number(req.body?.delta);

    const description =
      String(
        req.body?.description ||
        "Admin virtual coin adjustment"
      )
        .trim()
        .slice(0, 120);

    if (
      !targetUid ||
      !Number.isInteger(delta) ||
      delta === 0
    ) {
      return res.status(400).json({
        ok: false,
        error:
          "A valid target uid and non-zero integer delta are required."
      });
    }

    try {
      const economyRef =
        database.ref(
          `users/${targetUid}/economy`
        );

      const result =
        await economyRef.transaction(current => {
          const economy =
            normalizeEconomyRecord(
              current || {
                ludoCoins: STARTER_LUDOCOINS
              }
            );

          const nextBalance =
            economy.ludoCoins + delta;

          if (nextBalance < 0) {
            return;
          }

          return {
            ...economy,
            ludoCoins: nextBalance,
            updatedAt: Date.now()
          };
        });

      if (!result.committed) {
        return res.status(409).json({
          ok: false,
          error:
            "Adjustment would make the virtual balance negative."
        });
      }

      const transactionId =
        `admin_${crypto.randomUUID()}`;

      await database
        .ref(
          `users/${targetUid}/coinTransactions/${transactionId}`
        )
        .set({
          type:
            delta > 0
              ? "admin_credit"
              : "admin_debit",
          coins: delta,
          description,
          createdAt: Date.now(),
          adminUid: req.user.uid
        });

      return res.json({
        ok: true,
        uid: targetUid,
        delta,
        description,
        economy:
          normalizeEconomyRecord(
            result.snapshot.val()
          )
      });
    } catch (error) {
      console.error(
        "Admin economy adjustment failed:",
        error
      );

      return res.status(500).json({
        ok: false,
        error:
          "Could not adjust the virtual LudoCoin balance."
      });
    }
  }
);


/* =========================================================
   ERROR HANDLER
========================================================= */

app.use(
  (error, _req, res, _next) => {

    console.error(
      "Unhandled server error:",
      error
    );

    res.status(500).json({
      ok: false,
      error:
        "Internal server error."
    });
  }
);


/* =========================================================
   START
========================================================= */

app.listen(
  PORT,
  "127.0.0.1",
  () => {
    console.log(
      `LUDOVERSE backend running at http://127.0.0.1:${PORT}`
    );
  }
);
